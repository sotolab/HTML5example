var now = new Date();
document.write("현재 시간 : " + now);
